# Chrome 拡張
* [Vue.js devtools](https://chrome.google.com/webstore/detail/vuejs-devtools/nhdogjmejiglipccpnnnanhbledajbpd/related?hl=ja)

# VS Code 拡張
* [REST Client](https://marketplace.visualstudio.com/items?itemName=humao.rest-client)

# 補足
```bash
# キャッシュのクリア
composer dump-autoload
php artisan cache:clear
```

# 1. PHPパッケージのインストール
## 1-1. Laravel 8.x
```bash
composer create-project --prefer-dist "laravel/laravel=^8.0" .
```
## 1-2. Code Sniffer
```bash
composer require --dev squizlabs/php_codesniffer
```
## 1-3. Controller/Service/Repository
```bash
composer require --dev scrumble-nl/laravel-csr:^8.0
# /config/csr.php のインストール
php artisan vendor:publish --tag=laravel-csr
```
## 1-4. 多言語ファイル
```bash
composer require --dev laravel-lang/http-statuses:^2.0
composer require --dev laravel-lang/lang:^10.0
composer require --dev laravel-lang/publisher:^13.0
# /config/lang-publisher.php のインストール
php artisan vendor:publish --provider="LaravelLang\Publisher\ServiceProvider"
```

## ~~1.9 PostGIS~~
composer require mstaack/laravel-postgis

# 2. WebAPIの生成
## 2-1. モデルとマイグレーション、シーダを生成（ファクトリは任意）
```bash
php artisan make:model ImportFlight -ms
```

[Laravel Eloquent：モデル](https://learntutorials.net/ja/laravel/topic/7984/eloquent-%E3%83%A2%E3%83%87%E3%83%AB)

### マイグレーションにCREATE,DROP文を記述
### モデルに物理テーブル名、デフォルト値を記述
### マイグレーションの実行
```bash
# migrate実行
php artisan migrate
# 前回のmigrate戻し
php artisan migrate:rollback
# 戻し回数指定
php artisan migrate:rollback --step=5
# 全戻し
php artisan migrate:reset
```

###  シーダの実行
```bash
# 全seed実行
php artisan db:seed
# 個別実行
php artisan db:seed --class=ImportFlightSeeder
```

### 2-1. WebAPI用Controllerクラスの生成
```bash
# index,store,show,update,destroyの5つのルートが生成される
# 不要なルートは削除し、必要ルートは手動で追加する
php artisan make:controller ArticleController --api
```
|Method|Action|用途|
|--|--|--|
|GET|index|一覧参照|
|POST|store|新規追加|
|GET|show|個別参照|
|PUT|update|個別更新|
|DELETE|destroy|個別削除|

### 2-2. WebAPIのルート設定
* src\routes\api.php に追加
```bash
# ルート確認
php artisan route:list
```

### 2-3. Service/Repositoryクラスの生成
```bash
php artisan csr:gen Article --nc

# 4つのクラスが生成される
src\app\Interfaces\Repositories\IArticleRepository.php
src\app\Interfaces\Services\IArticleService.php
src\app\Repositories\ArticleRepository.php
src\app\Services\ArticleService.php
```

### 2-4 サービスプロバイダーへの登録
* AppServiceProvider.php に追加

### 3-1. 言語の追加
```bash
# jaの追加
php artisan lang:add ja
# 全言語の最新化
php artisan lang:update
```

### 3-2. Requestクラスの生成
* FormRequestを継承したApiRequest抽象クラスを作成
src\app\Http\Requests\ApiRequest.php

```bash
php artisan make:request Article/StoreRequest
```
* 継承元をFormRequestからApiRequestに変更
* ControllerのパラメータをRequestからStoreRequestに変更


# 参考
https://www.twilio.com/blog/repository-pattern-in-laravel-application
https://www.toptal.com/laravel/restful-laravel-api-tutorial
https://zenn.dev/moroshi/articles/56d02e4b9cabe0
https://qiita.com/apricotcomic/items/eaae832338a67e1ccf2a
https://qiita.com/reflet/items/76ce4d7743c7d9a8a963

https://github.com/yaza-putu/laravel-repository-with-service
https://github.com/training-yoyosan/example-backend
https://github.com/shin1x1/eh-laravel-sample