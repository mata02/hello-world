<?php

declare(strict_types=1);

namespace App\Repositories;

use App\Interfaces\Repositories\IArticleRepository;

class ArticleRepository implements IArticleRepository
{

}
