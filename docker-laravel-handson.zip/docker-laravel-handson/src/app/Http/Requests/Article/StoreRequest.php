<?php

namespace App\Http\Requests\Article;

use App\Http\Requests\ApiRequest;

class StoreRequest extends ApiRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        // TODO 認可処理の実装
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'user' => ['required', 'array'],
            'user.name' => ['required', 'string', 'max:12'],
            'user.birthday' => ['date', 'nullable'],
        ];
    }
}
