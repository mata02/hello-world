<?php

return [
    'next'     => '次へ &raquo;',
    'previous' => '&laquo; 前へ',
];
