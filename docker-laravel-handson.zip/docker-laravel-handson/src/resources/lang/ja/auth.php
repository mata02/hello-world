<?php

return [
    'failed'   => '認証に失敗しました。',
    'password' => 'パスワードが間違っています。',
    'throttle' => 'ログインの試行回数が多すぎます。:seconds 秒後にお試しください。',
];
