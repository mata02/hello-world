<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateImportFlightsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('import_flights', function (Blueprint $table) {
            $table->increments('id'); // serial
//            $table->bigIncrements('id'); // bigserial
            $table->bigInteger('big_votes'); // bigint
            $table->string('name', 100); // varchar
            $table->boolean('confirmed'); // boolean
            $table->decimal('amount', $precision = 12, $scale = 2); // decimal
            $table->geometry('position'); // geometry 
            $table->json('options'); // json
            $table->binary('photo')->nullable();; // bytea NULL許可
            $table->text('description'); //text
            $table->date('deleted_at'); // date
            $table->time('sunrise'); // time without time zone
            $table->timestamp('added_at')->useCurrent(); // timestamp without time zone
            $table->integer('version')->default(0); // integer default指定
            $table->timestamps(); // created_at、updated_at
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('import_flights');
    }
}
