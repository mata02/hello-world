<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ImportFlightSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('import_flights')->insert([
            [
                'big_votes' => 1,
                'name' => Str::random(10),
                'confirmed' => 0,
                'amount' => 10.1,
                'position' => '0101000020E61000000000000000E060400000000000804140',
                'options' => '{"bar": "baz", "balance": 7.77, "active": false}',
                'photo' => null,
                'description' => Str::random(100),
                'deleted_at' => today(),
                'sunrise' => '11:12:13',
                'added_at' => '2022-05-01 11:12:13',
                'version' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'big_votes' => 2,
                'name' => Str::random(20),
                'confirmed' => 0,
                'amount' => 10.1,
                'position' => '0101000020E61000000000000000E060400000000000804140',
                'options' => '{"bar": "baz", "balance": 7.77, "active": false}',
                'photo' => null,
                'description' => Str::random(200),
                'deleted_at' => today(),
                'sunrise' => '12:34:56',
                'added_at' => '2022-05-02 12:34:56',
                'version' => 1,
                'created_at' => now(),
                'updated_at' => now(),
            ]
        ]);
    }
}
