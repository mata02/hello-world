<?php

namespace Tests\Feature;

use Illuminate\Support\Facades\Artisan;
use Tests\TestCase;

class PostTaskTest extends TestCase
{
    private static $isRefresed = false;

    protected function setUp(): void
    {
        parent::setUp();

        if (!self::$isRefresed) {
            // ※RefreshDatabaseは全スキーマのテーブルを削除するため使用不可
            // 全てのマイグレーションをロールバック後、マイグレーションを実行
            Artisan::call('migrate:refresh');
            // シーダ実行
            Artisan::call('db:seed --class=TaskSeeder');
            self::$isRefresed = true;
        }
    }

    protected function tearDown(): void
    {
        parent::tearDown();
    }

    public function testPostTask()
    {
        $name = 'new task';

        $response = $this->postJson('/api/tasks', [  // (2)JSON を POST
            'name' => $name,
        ]);

        $id = $response->json(['id']);

        $response->assertStatus(201);  // (3)レスポンスの検証
        $response->assertJson([
            'id' => $id,
            'name' => $name,
        ]);

        $this->assertDatabaseHas('tasks', [ // (4)データベースの検証
            'id' => $id,
            'name' => $name,
        ]);
    }
}